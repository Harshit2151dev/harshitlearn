import UIKit

var greeting = "Hello, playground"
/*
let urlString = "https://jsonplaceholder.typicode.com/users"

struct User: Codable {
    var name: String?
    var username: String?
    var email: String?
}

class APIManager {
    static func fetchAPI() async throws -> [User]? {
        guard let url = URL(string: urlString) else {
            return nil
        }
        let (data, _) = try await URLSession.shared.data(from: url)
        print("Data is \(data)")
        let decoder = JSONDecoder()
        let users = try decoder.decode([User].self, from: data)
        print("Users is \(users)")
        return users
        
    }
}

Task {
    do {
        let users = try await APIManager.fetchAPI()
        users?.forEach { print($0.email ?? "")}
    } catch {
        print("Errors is \(error)")
    }
}


*/



import Foundation

// Define a struct conforming to Decodable
struct MyData: Decodable {
    let id: Int
    let values: [[String: Any]] // Array of dictionaries with String keys and Any values

    enum CodingKeys: String, CodingKey {
        case id
        case values
    }
}

// JSON data with an array of dictionaries with different types of values
let jsonData = """
{
    "id": 1,
    "values": [
        {
            "key1": "value1",
            "key2": 42
        },
        {
            "key1": 3.14,
            "key2": true
        }
    ]
}
""".data(using: .utf8)!

do {
    // Decode JSON data into MyData object
    let decoder = JSONDecoder()
    let decodedData = try decoder.decode(MyData.self, from: jsonData)
    print(decodedData)
} catch {
    print("Error decoding JSON: \(error)")
}



